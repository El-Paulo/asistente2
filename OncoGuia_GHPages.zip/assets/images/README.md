Coloca aquí tu imagen de fondo para el hero: assets/images/hero-bg.jpg

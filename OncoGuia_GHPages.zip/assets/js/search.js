// Simple client-side search using Fuse.js
document.addEventListener('DOMContentLoaded', function() {
  fetch("{{ '/search.json' | relative_url }}")
    .then(response => response.json())
    .then(data => {
      const fuse = new Fuse(data, { keys: ["title", "content"], threshold: 0.3 });
      const input = document.getElementById("search-input");
      input.addEventListener("input", function() {
        const results = fuse.search(this.value);
        let container = document.getElementById("search-results");
        if (!container) {
          container = document.createElement("div");
          container.id = "search-results";
          input.parentNode.appendChild(container);
        }
        container.innerHTML = results.map(r =>
          `<a href="${r.item.url}" class="list-group-item list-group-item-action">${r.item.title}</a>`
        ).join("");
      });
    });
});

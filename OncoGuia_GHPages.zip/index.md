---
layout: default
title: OncoGuía Pro
---

<div class="hero">
  <h1>Bienvenido a OncoGuía Pro</h1>
  <p>Guías prácticas de oncología</p>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-4">
      <h2>Guía de tratamiento CAPOX</h2>
      <p>Orientación rápida y práctica sobre el esquema CAPOX.</p>
      <a href="/guides/capox.html" class="btn btn-primary">Ver guía</a>
    </div>
    <!-- Añade más tarjetas según sea necesario -->
  </div>
</div>
